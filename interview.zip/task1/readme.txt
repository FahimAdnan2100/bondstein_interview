
create database
save interview folder in htdocs in xampp.
then go to this url localhost/interview/task1/review_file.html